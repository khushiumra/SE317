package lab4;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import java.io.*;
import java.util.*;
import org.junit.*;
// ...
import org.junit.rules.*;
// ...

public class HandsOnExperience {
	class InsufficientFundsException extends RuntimeException {
	      public InsufficientFundsException(String message) {
	         super(message);
	      }

	      private static final long serialVersionUID = 1L;
	   }

	   class Account {
	      int balance;
	      String name;

	      Account(String name) {
	         this.name = name;
	      }

	      void deposit(int dollars) {
	         balance += dollars;
	      }

	      void withdraw(int dollars) {
	         if (balance < dollars) {
	            throw new InsufficientFundsException("balance only " + balance);
	         }
	         balance -= dollars;
	      }

	      public String getName() {
	         return name;
	      }

	      public int getBalance() {
	         return balance;
	      }

	      public boolean hasPositiveBalance() {
	         return balance > 0;
	      }
	   }

	   class Customer {
	      List<Account> accounts = new ArrayList<>();

	      void add(Account account) {
	         accounts.add(account);
	      }

	      Iterator<Account> getAccounts() {
	         return accounts.iterator();
	      }
	   }
	   private Account account;
	   //TO DO
	   
	   // You need to create test cases in Here
	  

}
