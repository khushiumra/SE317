package lab7;

public enum Gear {
		   DRIVE, PARK
}
