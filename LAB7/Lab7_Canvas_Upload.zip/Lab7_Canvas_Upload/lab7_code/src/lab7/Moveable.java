package lab7;

public interface Moveable {
	
	   int currentSpeedInMph();


}
